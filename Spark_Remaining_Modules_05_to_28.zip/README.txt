Spark Remaining Modules 05-28

24 DOCX modules. Each contains 20 questions, answers, and answers to all follow-up questions, plus traps, scenarios, internals and performance guidance.
Modules 02-04 were already generated separately.
